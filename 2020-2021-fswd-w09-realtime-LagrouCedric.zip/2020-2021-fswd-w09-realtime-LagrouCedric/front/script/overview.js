'use strict';

const lanIP = `${window.location.hostname}:5000`;
const socket = io(`http://${lanIP}`);

const showTable = function (json) {
  const table = document.querySelector('.js-table');
  let html;
  html += `<tr class="c-row is-header">
  <th class="c-cell">Date</th>
  <th class="c-cell">Amount</th>`;
  for (let rij of json) {
    html += `
  <tr class="c-row">
    <td class="c-cell">${rij.date}</div>
    <td class="c-cell">${rij.amount}</div>
</tr>`;
  }
  table.innerHTML = html;
};
function callbackWissenGelukt() {
  console.log('Wissen gelukt');
}
const listenToUI = function () {
  document.querySelector('.js-clear-amount-today').addEventListener('click', () => {
    handleData(`http://${lanIP}/api/v1/progress/today`, callbackWissenGelukt, null, 'DELETE');
  });
};

function listenToSocket() {
  socket.on('B2F_addProgress', (value) => {
      console.log('Progress added')
    handleData(`http://${lanIP}/api/v1/progress`, showTable, null, 'GET');
    console.log(value);
  });

  socket.on('B2F_clear', () => {
    handleData(`http://${lanIP}/api/v1/progress`, showTable, null, 'GET');
    console.log('cleardata');
  });
}

const init = function () {
  listenToUI();
  listenToSocket();
  handleData(`http://${lanIP}/api/v1/progress`, showTable, null, 'GET');
};

document.addEventListener('DOMContentLoaded', init);
