'use strict';

let htmlAddButton, htmlWave, htmlPercentage;
const dailyGoal = 1500;
let currentProgress = 0; // in milliliter
// !!
const lanIP = `${window.location.hostname}:5000`;
//!!! PAS DIT AAN ZODAT DIT dynamisch wordt !!!
// const lanIP = `0.0.0.0:5000`; //!!! PAS DIT AAN ZODAT DIT dynamisch wordt !!!

// !!
const socket = io(lanIP);

const updateView = function (waarde) {
    htmlPercentage.innerHTML = waarde;
    htmlWave.style.transform = `translateY(${100 - waarde}%)`;
};

//listeners
const listenToUI = function () {
  let waterwaarde = document.querySelectorAll('.js-water-amount');
  for (let index of waterwaarde) {
    index.addEventListener('change', (e) => {
      let aantal = index.getAttribute('data-amount');
      document.querySelector('.js-log').innerHTML = aantal;
      htmlAddButton.setAttribute('data-amount', aantal);
    });
  }
  htmlAddButton.addEventListener('click', (e) => {
      console.log('water toevoegen')
    let aantal = htmlAddButton.dataset.amount;
    console.log(`er wordt ${aantal} ml gedronken`);
    socket.emit('F2B_new_logging', {amount: aantal})
    
  });
};

const listenToSocket = function () {
  socket.on('connected', (e) => {
    console.log('Verbonden met socket webserver');
  });

  socket.on('B2F_connected', (jsonObject) => {
    // console.log(jsonObject)
    let percentage = Math.ceil((currentProgress / dailyGoal) * 100);
    currentProgress = jsonObject.currentProgress;
    console.log(`eerste boodschap server: huidig aantal ml gedronken in DB ${jsonObject.currentProgress} ml`);
    updateView(percentage);
  });

  socket.on('B2F_addProgress', value => {
    currentProgress += parseInt(value.amount);
    const progressInPercentage = Math.ceil((currentProgress / dailyGoal) * 100);
    updateView(progressInPercentage);
})
};

const init = function () {
  htmlAddButton = document.querySelector('.js-log-water');
  htmlWave = document.querySelector('.js-waves');
  htmlPercentage = document.querySelector('.js-percentage');
  document.querySelector(".js-goal").innerHTML = dailyGoal;
  listenToUI();
  listenToSocket();
};

document.addEventListener('DOMContentLoaded', init);
